import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Course {
    private final List<Student> students = new ArrayList<>();
    private final List<Assignment> assignments = new ArrayList<>();
    private final List<Project> projects = new ArrayList<>();
    private String name;
    private Teacher professor;
    private int unitsNum;
    private int studentsNum;
    private boolean isAvailable;
    private int assignmentsNum;
    private Date examDate;

    public void getStudents() {
        students.sort((student1, student2) -> student1.getName().compareToIgnoreCase(student2.getName()));
        students.forEach(System.out::println);
    }
    public void addStudent(Student student) {
        students.add(student);
    }
    public void removeStudent(Student student) {
        students.remove(student);
    }

    public int getUnitsNum() {
        return unitsNum;
    }

//    public int bestScore() {
//
//    }
}
