import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Project {
    private LocalDateTime deadline;
    private boolean isAvailable;

    public Project(int days, int hours, int minutes) {
        this(days, hours);
        deadline = deadline.plusMinutes(minutes);
    }

    public Project(int days, int hours) {
        deadline = LocalDateTime.now().plusDays(days)
                .plusHours(hours);
    }

    public void setDeadline(LocalDateTime deadline) {
        this.deadline = deadline;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    public boolean isAvailable() {
        return isAvailable;
    }
    public void showTime() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss a");
        String time = deadline.format(formatter);
        System.out.println(time);
    }
}
