import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Student {
    private final List<Course> courses = new ArrayList<>();
    private final String name;
    private final String ID;
    private double totalAverage;
    private double GPAOfCurrentSemester;

    public Student(String name, String ID) {
        this.name = name;
        this.ID = ID;
    }

    public void getCourses() {
        courses.forEach(System.out::println);
    }

    public String getName() {
        return name;
    }

    public int getCourseNum() {
        return courses.size();
    }

    public String getID() {
        return ID;
    }

    public int getAdoptedUnitsNum() {
        int adoptedUnitsNum = 0;
        for(Course course: courses) {
            adoptedUnitsNum += course.getUnitsNum();
        }
        return adoptedUnitsNum;
    }

    public double getTotalAverage() {
        return totalAverage;
    }

    public void setTotalAverage(double totalAverage) {
        this.totalAverage = totalAverage;
    }

    public double getGPAOfCurrentSemester() {
        return GPAOfCurrentSemester;
    }

    public void setGPAOfCurrentSemester(double GPAOfCurrentSemester) {
        this.GPAOfCurrentSemester = GPAOfCurrentSemester;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student student = (Student) o;
        return Objects.equals(ID, student.ID);
    }

    @Override
    public int hashCode() {
        return Objects.hash(ID);
    }
}
