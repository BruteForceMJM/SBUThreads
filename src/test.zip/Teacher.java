import java.util.ArrayList;
import java.util.List;

public class Teacher {
    private String firstName;
    private String lastName;
    private String id;
    private int coursesNum;
    private List<Course> courses = new ArrayList<>();

    public Teacher(String firstName, String lastName, String id) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.id = id;
    }


}
